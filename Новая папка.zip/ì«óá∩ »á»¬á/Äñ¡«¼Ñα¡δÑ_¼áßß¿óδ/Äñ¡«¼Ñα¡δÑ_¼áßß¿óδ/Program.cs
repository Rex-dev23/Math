﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите элементы массива через пробел: ");
        string input = Console.ReadLine();

        // Разбиваем строку на элементы массива
        string[] inputArr = input.Split(' ');

        // Создаем список и заполняем его элементами из строки
        List<int> arr = new List<int>();
        for (int i = 0; i < inputArr.Length; i++)
        {
            arr.Add(int.Parse(inputArr[i]));
        }

        // Создаем множество для хранения уникальных элементов
        HashSet<int> distinctSet = new HashSet<int>(arr);

        Console.WriteLine($"Количество различных чисел в массиве: {distinctSet.Count}");

        Console.ReadKey();
    }
}
