﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Запрашиваем у пользователя размеры многомерного массива
        Console.Write("Введите количество строк: ");
        int rows = int.Parse(Console.ReadLine());

        Console.Write("Введите количество столбцов: ");
        int cols = int.Parse(Console.ReadLine());

        // Создаем многомерный массив заданного размера
        int[,] arr = new int[rows, cols];

        // Заполняем массив данными, введенными пользователем
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                Console.Write($"Введите элемент [{i}, {j}]: ");
                arr[i, j] = int.Parse(Console.ReadLine());
            }
        }

        // Выводим массив на экран
        Console.WriteLine("Массив:");
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                Console.Write(arr[i, j] + " ");
            }
            Console.WriteLine();
        }
    }
}
