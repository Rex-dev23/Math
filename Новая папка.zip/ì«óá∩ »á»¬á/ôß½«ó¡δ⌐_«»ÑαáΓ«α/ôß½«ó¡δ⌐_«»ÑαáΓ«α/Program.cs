﻿using System;





/*2
class Program
{
    static void Main(string[] args)
    {
        // Запрос ввода радиуса шара
        Console.Write("Введите радиус шара: ");
        double r = double.Parse(Console.ReadLine());

        // Запрос ввода длины стороны куба
        Console.Write("Введите длину стороны куба: ");
        double a = double.Parse(Console.ReadLine());

        // Запрос ввода длины ребра пирамиды
        Console.Write("Введите длину ребра пирамиды: ");
        double l = double.Parse(Console.ReadLine());

        // Вычисление объема шара
        double sphereVolume = (4.0 / 3.0) * Math.PI * Math.Pow(r, 3);

        // Вычисление объема куба
        double cubeVolume = Math.Pow(a, 3);

        // Вычисление объема правильной пирамиды
        double pyramidVolume = (1.0 / 3.0) * Math.Pow(l, 2) * Math.Sqrt(3) * l;

        // Определение фигуры с наибольшим объемом
        string largestFigure = "";
        double largestVolume = 0;

        if (sphereVolume > largestVolume)
        {
            largestVolume = sphereVolume;
            largestFigure = "Шар";
        }

        if (cubeVolume > largestVolume)
        {
            largestVolume = cubeVolume;
            largestFigure = "Куб";
        }

        if (pyramidVolume > largestVolume)
        {
            largestVolume = pyramidVolume;
            largestFigure = "Пирамида";
        }

        // Вывод результата на экран
        Console.WriteLine($"Фигура с наибольшим объемом: {largestFigure}");

        Console.ReadKey();
    }
}
*/