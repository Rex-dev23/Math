﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите знак препинания: ");
        char punctuation = Console.ReadKey().KeyChar;
        Console.WriteLine();

        switch (punctuation)
        {
            case '.':
                Console.WriteLine("Точка");
                break;
            case ',':
                Console.WriteLine("Запятая");
                break;
            case ';':
                Console.WriteLine("Точка с запятой");
                break;
            case ':':
                Console.WriteLine("Двоеточие");
                break;
            case '!':
                Console.WriteLine("Восклицательный знак");
                break;
            case '?':
                Console.WriteLine("Вопросительный знак");
                break;
            default:
                Console.WriteLine("Неизвестный знак препинания");
                break;
        }

        Console.ReadKey();
    }
}
