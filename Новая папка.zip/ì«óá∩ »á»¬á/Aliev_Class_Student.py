# Определяем класс Студент с атрибутами номер и фамилия, а также методом Hello
class Student:
    def __init__(self, number, last_name):
        self.number = number
        self.last_name = last_name
    
    def Hello(self):
        print("Привет я {}.".format(self.last_name))
 
# Создаем пустой список для хранения объектов студентов
students = []
 
# Открываем файл "students.txt"
with open("students.txt", "r") as f:
    for line in f:
        # Разделяем каждую строку по запятой, чтобы получить номер и фамилию
        number, last_name = line.strip().split(",")
        #новый объект класса Студент с номером и фамилией
        students.append(Student(int(number), last_name,))
 

for s in students:
    s.Hello()